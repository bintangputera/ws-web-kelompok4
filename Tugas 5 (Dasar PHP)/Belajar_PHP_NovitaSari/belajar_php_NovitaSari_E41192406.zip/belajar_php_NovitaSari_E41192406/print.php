<?php
print "<h2>Belajar PHP dari Nol!";
print "Hello world!<br>";
print "Belajar mecetak teks di PHP!";
?>