<?php
echo "<h2>Belajar PHP itu mudah!</h2>";
echo("Hello World!<br>");
echo "Aku sedang belajar PHP!<br>";
echo "Ini ", "teks ", "yang ", "dibuat ", "terpisah.";
?>