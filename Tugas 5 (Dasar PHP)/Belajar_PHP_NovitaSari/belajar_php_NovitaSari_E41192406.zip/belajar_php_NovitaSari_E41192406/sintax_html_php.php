<!DOCTYPE html>
<html>
<head>
    <title><?php echo "Belajar PHP" ?></title>
</head>
<body>
    <?php 
        echo "Saya sedang belajar PHP<br>";
        echo "<p>Belajar PHP hingga jadi master</p>";
    ?>
</body>
</html>