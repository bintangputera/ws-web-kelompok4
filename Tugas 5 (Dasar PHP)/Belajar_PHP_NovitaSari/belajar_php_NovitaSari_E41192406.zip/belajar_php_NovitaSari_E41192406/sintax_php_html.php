<?php

echo "<html>";
echo "<head>";
echo "<title>Judul Web</title>";
echo "</head>";
echo "<body>";
echo "<h1>Selamat datang</h1>";
echo "</body>";
echo "</html>";
?>