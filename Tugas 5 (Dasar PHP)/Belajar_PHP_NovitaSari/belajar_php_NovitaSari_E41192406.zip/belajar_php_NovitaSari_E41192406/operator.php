<?php

$a = 5;
$b = 2;

// Penjumlahan
$c = $a + $b;
echo "$a - $b = $c";
echo "<hr>";

// pengurangan
$c = $a - $b;
echo "$a - $b = $c";
echo "<hr>";

// perkalian
$c = $a * $b;
echo "$a * $b = $c";
echo "<hr>";

// pembagian
$c = $a / $b;
echo "$a / $b = $c";
echo "<hr>";

// sisa bagi
$c = $a % $b;
echo "$a % $b = $c";
echo "<hr>";

// pangkat
$c = $a ** $b;
echo "$a ** $b = $c";
echo "<hr>";
?>